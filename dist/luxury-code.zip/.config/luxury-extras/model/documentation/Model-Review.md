##### {DocumentationIndex|Home} > {Model/DataModel|Data Model} > {Model/Dictionary/Dictionary|Data Dictionary} > {Model/Dictionary/Model-Review|Review Table}

Review
===

Column Name | Size | Data Type | Join 
----------- | ---: | --------- | ---- 
IDReviews |  | ID |  
GUIDReviews |  | GUID |  
CreateDate |  | DateTime |  
CreatingIDUser |  | Numeric |  
UpdateDate |  | DateTime |  
UpdatingIDUser |  | Numeric |  
Deleted |  | Boolean |  
DeleteDate |  | DateTime |  
DeletingIDUser |  | Numeric |  
Text |  | Text |  
Rating |  | Numeric |  
IDBook |  | Numeric | Book.IDBook 
- - -

Generated on 2022-03-29 at 11:36
