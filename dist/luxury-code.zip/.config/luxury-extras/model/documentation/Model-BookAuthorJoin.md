##### {DocumentationIndex|Home} > {Model/DataModel|Data Model} > {Model/Dictionary/Dictionary|Data Dictionary} > {Model/Dictionary/Model-BookAuthorJoin|BookAuthorJoin Table}

BookAuthorJoin
===

Column Name | Size | Data Type | Join 
----------- | ---: | --------- | ---- 
IDBookAuthorJoin |  | ID |  
GUIDBookAuthorJoin |  | GUID |  
IDBook |  | Numeric | Book.IDBook 
IDAuthor |  | Numeric | Author.IDAuthor 
- - -

Generated on 2022-03-29 at 11:36
