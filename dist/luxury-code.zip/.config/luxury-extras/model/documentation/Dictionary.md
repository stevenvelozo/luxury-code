##### {DocumentationIndex|Home} > {Model/DataModel|Data Model} > {Model/Dictionary/Dictionary|Data Dictionary}

Data Dictionary
=========================

Each entry below describes a single table in the database.

Table | Column Count 
----- | -----------: 
{Model/Dictionary/Model-Book|Book} | 16
{Model/Dictionary/Model-BookAuthorJoin|BookAuthorJoin} | 4
{Model/Dictionary/Model-Author|Author} | 10
{Model/Dictionary/Model-BookPrice|BookPrice} | 15
{Model/Dictionary/Model-Review|Review} | 12

- - -

Generated on 2022-03-29 at 11:36
