##### {DocumentationIndex|Home} > {Model/DataModel|Data Model} > {Model/Dictionary/Dictionary|Data Dictionary} > {Model/Dictionary/Model-Author|Author Table}

Author
===

Column Name | Size | Data Type | Join 
----------- | ---: | --------- | ---- 
IDAuthor |  | ID |  
GUIDAuthor |  | GUID |  
CreateDate |  | DateTime |  
CreatingIDUser |  | Numeric |  
UpdateDate |  | DateTime |  
UpdatingIDUser |  | Numeric |  
Deleted |  | Boolean |  
DeleteDate |  | DateTime |  
DeletingIDUser |  | Numeric |  
Name | 200 | String |  
- - -

Generated on 2022-03-29 at 11:36
