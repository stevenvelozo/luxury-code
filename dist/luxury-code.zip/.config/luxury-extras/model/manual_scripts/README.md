This folder contains any hand-written scripts... currently just the script 
to drop tables for rapid DB changes and sketches.